# proguard (minify tắt)
